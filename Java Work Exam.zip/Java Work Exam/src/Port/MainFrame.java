package Port;
//--> NAME: Versabia Mª Moraga López

import PaqI04.Hub;
import PaqI04.Container;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class MainFrame extends JFrame{
    private JTextField text1;
    private JTextField text2;
    private JTextArea description1;
    private JTextField text3;
    private JTextField text4;
    private JButton pileButton;
    private JButton unpileButton;
    private JButton showDButton;
    private JButton numCButton;
    private JTextField text5;
    private JTextArea description2;
    private JTextField text6;
    private JCheckBox check1;
    private JTextArea description3;
    private JRadioButton Rbutton02;
    private JRadioButton Rbutton01;
    private JComboBox Cbox2;
    private JPanel mainPanel;
    private JComboBox cbox1;
    private JRadioButton Rbutton03;
    private JPanel logo;
    private JRadioButton RbHub1;
    private JRadioButton RbHub2;
    private JRadioButton RbHub3;
    private JButton compWeight;
    private JTextField text21;
    private JTextArea Weightcomp;
    private JTextField textWeight2;

    public MainFrame(){
        setTitle("Port");
        setBounds(150,-10,1200, 1500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setContentPane(mainPanel);

        
        Hub x = new Hub();
        Hub x2 = new Hub();
        Hub x3 = new Hub();
        Container c = new Container();


        numCButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                text6.setText(String.valueOf(x.contC((String) cbox1.getSelectedItem()) + x2.contC((String) cbox1.getSelectedItem())
                        + x3.contC((String) cbox1.getSelectedItem())));
            }
        });
        showDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String desc1 = description1.getText();

                description2.setText(c.toString());
            }
        });
        addWindowListener(new WindowListener() {

            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                int option = JOptionPane.showConfirmDialog(
                        null,
                        "Are you sure you want to cease the operation?",
                        "Closure confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE);
                if (option == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });


    //PILE:
        pileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    c.setId(Integer.parseInt(text1.getText()));
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null, "The ID introduced is not valid");
                }
                try {
                    c.setId(Integer.parseInt(text2.getText()));
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null, "The weight introduced is not valid");
                }

                c.setId(Integer.parseInt(text1.getText()));
                c.setDescription(description1.getText());
                c.setCountry((String)cbox1.getSelectedItem());
                if (Rbutton01.isSelected()) c.setPriority(1);
                if (Rbutton02.isSelected()) c.setPriority(2);
                if (Rbutton03.isSelected()) c.setPriority(3);


                c.inspected = check1.isSelected();
                c.setEmisor(text3.getText());
                c.setReceptor(text4.getText());

                if(RbHub1.isSelected()){
                    x.apilar(c);
                    description3.setText(x.toString());
                }
                if(RbHub2.isSelected()){
                    x2.apilar(c);
                    description3.setText(x2.toString());
                }
                if(RbHub3.isSelected()){
                    x3.apilar(c);
                    description3.setText(x3.toString());
                }

            }
        });


    //UNPILE:
        unpileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                if(RbHub1.isSelected()){
                    x.desapilar(Integer.parseInt(text5.getText()));
                    description3.setText(x.toString());
                }
                if(RbHub2.isSelected()){
                    x2.desapilar(Integer.parseInt(text5.getText()));
                    description3.setText(x2.toString());
                }
                if(RbHub3.isSelected()){
                    x3.desapilar(Integer.parseInt(text5.getText()));
                    description3.setText(x3.toString());
                }

            }
        });
        compWeight.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               c.setWeight(Integer.parseInt(text2.getText()));
               c.setWeight2(Integer.parseInt(text21.getText()));
               Weightcomp.setText(c.toStringW());
            }
        });
    }


    //MAIN:
    public static void main(String[] args) {

        MainFrame myFrame = new MainFrame();
    }
}
